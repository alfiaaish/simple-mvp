package com.example.mvpsimple.View;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.mvpsimple.Presenter.LoginInteractor;
import com.example.mvpsimple.Presenter.LoginPresenter;
import com.example.mvpsimple.R;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements LoginView {


    EditText etUsername, etPassword;
    Button Login;

    LoginPresenter loginPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        loginPresenter = new LoginPresenter(this, new LoginInteractor());
    }

    void initViews() {
        etUsername = findViewById(R.id.Username);
        etPassword = findViewById(R.id.Password);

        progressbar = findViewById(R.id.progressbar);
        Button = findViewById(R.id.Login);
    }

    public void loginMe(View view) {
        showProgressbar();

        loginPresenter.validateCredentials(etUsername.getText().toString().trim(), etPassword.getText().toString().trim());
    }

    @Override
    public void setUsernameError() {
        hideProgressbar();
        etUsername.setError("Username can't be empty!");

    }

    @Override
    public void setPasswordError() {

        hideProgressbar();
        etPassword.setError("password can't be empty!");
    }

    @Override
    public void onLoginSuccess(String username) {


        Intent intent = new Intent(this, WelcomeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);

    }

    @Override
    public void onLoginError() {
        hideProgressbar();

        Toast.makeText(this, "username or password doesn't match", Toast.LENGTH_LONG).show();
    }

    @Override
    public void showProgressbar() {

        progressbar.setVisibility(View.VISIBLE);

    }

    @Override
    public void hideProgressbar() {

        progressbar.setVisibility(View.GONE);

    }
}