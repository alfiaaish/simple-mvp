package com.example.mvpsimple.View;

class WelcomeActivity {
}
